﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;


namespace Tutorial1
{
    public partial class MyMasterDetailPage : MasterDetailPage
    {
        public MyMasterDetailPage()
        {
            InitializeComponent();


        }

    }
}

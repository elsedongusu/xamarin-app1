﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Tutorial1.Views
{
    public partial class TabPage2 : ContentPage
    {
        public TabPage2()
        {
            InitializeComponent();
        }
    }
}

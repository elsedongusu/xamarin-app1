﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Tutorial1.Views
{
    public partial class MyDetailPage : ContentPage
    {
        public MyDetailPage()
        {
            InitializeComponent();
        }
    }
}

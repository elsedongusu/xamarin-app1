﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Tutorial1.Views
{
    public partial class TabPage1 : ContentPage
    {
        public TabPage1()
        {
            InitializeComponent();
        }
    }
}
